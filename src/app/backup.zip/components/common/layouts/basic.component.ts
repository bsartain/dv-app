import { Component } from '@angular/core';

declare var jQuery:any;

@Component({
    selector: 'basic',
    templateUrl: 'basic.template.html'
})
export class basicComponent {}