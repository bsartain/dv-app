import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from "@angular/router";
import { LocationStrategy, HashLocationStrategy } from '@angular/common';

import { ROUTES } from "./app.routes";
import { AppComponent } from './app.component';

// App views
import { MainViewModule } from "./views/main-view/main-view.module";
import { MinorViewModule } from "./views/minor-view/minor-view.module";
import { LoginModule } from "./views/login/login.module";
import { RegisterModule } from "./views/register/register.module";

// App modules/components
import { LayoutsModule } from "./components/common/layouts/layouts.module";
import { DashboardComponent } from './dashboard/dashboard.component';
import { DashboardPipe } from './dashboard/dashboard.pipe';
import { SharedqueryPipe } from './dashboard/sharedquery.pipe';
import { ToasterModule, ToasterService } from 'angular2-toaster';
import { DataTableModule } from "angular2-datatable";
import { NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { QuerydataComponent } from './querydata/querydata.component';
import { DropZoneWidgetGroupbyComponent } from './drop-zone-widget-groupby/drop-zone-widget-groupby.component';
import { DropZoneWidgetComponent } from './drop-zone-widget/drop-zone-widget.component';
import { DropZoneWidgetMeasureComponent } from './drop-zone-widget-measure/drop-zone-widget-measure.component';
import { DzfilterComponent } from './dzfilter/filter.component';
import { DimensionsComponent } from './dimensions/dimensions.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    DashboardPipe,
    SharedqueryPipe,
    QuerydataComponent,
    DropZoneWidgetGroupbyComponent,
    DropZoneWidgetComponent,
    DropZoneWidgetMeasureComponent,
    DzfilterComponent,
    DimensionsComponent
  ],
  imports: [
    // Angular modules
    BrowserModule,
    FormsModule,
    HttpModule,
    ToasterModule,
    DataTableModule,
    NgbModule.forRoot(),

    // Views
    MainViewModule,
    MinorViewModule,
    LoginModule,
    RegisterModule,

    // Modules
    LayoutsModule,

    RouterModule.forRoot(ROUTES)
  ],
  providers: [{provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
