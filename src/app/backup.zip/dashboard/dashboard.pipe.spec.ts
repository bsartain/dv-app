import { DashboardPipe } from './dashboard.pipe';

describe('DashboardPipe', () => {
  it('create an instance', () => {
    const pipe = new DashboardPipe();
    expect(pipe).toBeTruthy();
  });
});
