import { Component } from '@angular/core';

@Component({
    selector: 'login',
    templateUrl: 'login.template.html'
})
export class loginComponent { }