import { Component, EventEmitter, OnInit, ElementRef, Directive, Input, Output  } from '@angular/core';
import { DashboardService } from './dashboard.service';
import { BrowserModule } from '@angular/platform-browser';
import { DashboardPipe } from './dashboard.pipe';
import { SharedqueryPipe } from './sharedquery.pipe';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Notes, DeleteQuery, ShareQuery } from './queryparameters';
import { ToasterContainerComponent, ToasterService } from 'angular2-toaster';

declare var jQuery: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  providers: [DashboardService, Notes, DeleteQuery, ShareQuery, ToasterService]
})
export class DashboardComponent implements OnInit {

  dashboards: any = []; 
  shared: any = []; 
  desc = 'This is a description value.';

  private toasterService: ToasterService;
  private plainDescDiv = true;
  private isEditing = false;
  public oldValue: any;

  constructor(
    private __dashdata: DashboardService, 
    private _elRef: ElementRef, 
    public _notes: Notes, 
    public _deletequery: DeleteQuery,
    public _share: ShareQuery,
    toasterService: ToasterService
  ) {
    this.toasterService = toasterService;
  }

  //Shows edit description 
  showEdit(dashboard) {
    dashboard.isEditing = true;
    this.plainDescDiv = false;
  }

  //Hides edit description 
  cancelEdit(dashboard) {
    dashboard.isEditing = false;
    this.plainDescDiv = true;
    this._notes = this.oldValue;
    console.log('This should revert' + JSON.stringify(this.oldValue));
  }

  ngOnInit() {

     this.__dashdata.dashboardData().subscribe(
       (data) => this.dashboards = data,
     )

     this.__dashdata.sharedQueryLibrary().subscribe(
       (shared_queries) => this.shared = shared_queries,
     )

    //On click allows table to reveal the description properties of the reports.
    //Angular 2 click event did not suffice. Pulled in jQuery. 
    jQuery(this._elRef.nativeElement).on('click', '.reveal', function(event){
      jQuery(this).closest('tr').next('tr').toggleClass('hide-desc', 'slow');
      jQuery(this).children('i').toggleClass("fa fa-plus-square-o fa fa-minus-square-o");
    });

    this.oldValue = this._notes;

  }
        

  updateDashNotes(user: string, id: number, description: string, dashboard){
    
    this._notes.user = user,
    this._notes.query_id = id,
    this._notes.description = description

    this.__dashdata.updateDashNotesMethod(this._notes).subscribe(
      (data) => this.toasterService.pop('success', 'Your note was updated'),
      (err) => this.toasterService.pop('error', 'Your note failed to update'),
      () => console.log('Request complete')
    );

    dashboard.isEditing = false;
    this.plainDescDiv = true;
    this.oldValue = this._notes;
    console.log('This is the Old Value' + JSON.stringify(this.oldValue));
  }

  deleteQuery(user:string, id:number, dashboard){ 

    this._deletequery.user = user,
    this._deletequery.query_id = id

    let confirmed = confirm("Are you sure you want to delete this query?");
    if(confirmed){
      this.__dashdata.deleteQueriesMethod(this._deletequery).subscribe()
      location.reload();
    }
    console.log(this.isEditing = false);
  }

  shareQuery(user: string, id: number, sharenum: number){
    
    this._share.user = user;
    this._share.query_id = id;
    this._share.share = sharenum;

    this.__dashdata.shareQueryMethod(this._share).subscribe(
      (data) => this.toasterService.pop('success', 'Your query was shared', 'Your query can now be viewed within the shared tab'),
      (err) => this.toasterService.pop('error', 'Your query was not shared', 'There was an error when trying to share your query'),
      () => console.log('Request complete')
    );

    
  }

}
