//Sets up parameters to pass in to the updateDashNotesMethod(notes: Notes)
export class Notes{
  user: string;
  query_id: any;
  description: string;
}

export class DeleteQuery{
  user: string;
  query_id: any;
}

export class ShareQuery{
  user: string;
  query_id: number;
  share:number
}